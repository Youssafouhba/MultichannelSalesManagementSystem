import React from 'react'
import { Text, View } from 'react-native'

export default function Messages() {
  return (
    <View>
        <Text>
            hello contact
        </Text>
    </View>
  )
}
