import React from 'react';
import TabLayout from './_layout';

import HomePage from '../../screens/HomePage';



export default function Index() {
  return (
    <HomePage/>
  );
}