import React from 'react'
import { Text, View } from 'react-native'

export default function Notifications() {
  return (
    <View>
      <Text>hello world</Text>
    </View>
  )
}
