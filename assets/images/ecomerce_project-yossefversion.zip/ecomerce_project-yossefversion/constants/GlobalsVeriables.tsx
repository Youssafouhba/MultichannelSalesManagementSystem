export const API_BASE_URL = 'http://100.70.32.51:8080';
export const CLOUDINARY_URL = `https://api.cloudinary.com/v1_1/dlkvn0fpz/image/upload`;
export const UPLOAD_PRESET = 'd1zmuabv';
import {Dimensions} from "react-native";

export const cartItemsNumber = 0

export const { width: screenWidth, height: screenHeight } = Dimensions.get('window');